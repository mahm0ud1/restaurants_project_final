interface HandleCloseInterface {
    closeFunction: ()=>void
}

export default HandleCloseInterface;