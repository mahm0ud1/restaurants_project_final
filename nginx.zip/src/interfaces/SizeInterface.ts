interface Size {
    height: string,
    width: string
}

export default Size;