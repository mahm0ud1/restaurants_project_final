interface DialogHeaderProps {
    windowName:string,
    handleClose: ()=>void;
}

export default DialogHeaderProps;