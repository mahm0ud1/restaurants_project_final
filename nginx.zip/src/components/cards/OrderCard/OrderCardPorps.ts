interface OrderCardProps {
    id: number,
    imageUrl:string,
    title: string,
    details: string,
    price: number
}

export default OrderCardProps;