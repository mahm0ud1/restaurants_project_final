import styled from "styled-components";

const HeaderContainer = styled.div`

`
const OutletContainer = styled.div`
    
`
const FooterContainer = styled.div`
    
`

export {HeaderContainer, OutletContainer, FooterContainer};