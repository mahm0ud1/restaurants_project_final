const ChefCard = () => {
    return (
        <></>
    );
}

export default ChefCard;