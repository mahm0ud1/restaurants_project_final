const Chefs = () => {
    return (
        <></>
    );
}

export default Chefs;