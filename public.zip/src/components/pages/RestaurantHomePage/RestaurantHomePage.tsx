const RestaurantHomePage = () => {
    return (
        <>RestaurantHomePage</>
    );
}

export default RestaurantHomePage;