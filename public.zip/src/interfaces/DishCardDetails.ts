interface DishCardDetails {
    imageUrl: string,
    title: string,
    details: string,
    signature: string,
    price: string
}

export default DishCardDetails;