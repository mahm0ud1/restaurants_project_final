interface RestaurantCardDetails {
    imageUrl: string,
    title: string,
    details: string
}

export default RestaurantCardDetails;